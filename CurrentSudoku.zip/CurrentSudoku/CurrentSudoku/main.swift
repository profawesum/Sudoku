//
//  main.swift
//  CurrentSudoku
//
//  Created by Harrison Orsbourne on 26/08/19.
//  Copyright © 2019 Harrison Orsbourne. All rights reserved.
//

import Foundation

//gets the position of the character
func CharacterPosition(_ pos: Int,_ from: String) -> Character
{
    let temp = from;
    let index = temp.index(temp.startIndex, offsetBy: pos);
    return (temp[index])
}


//draws the grid
func DrawGrid(view: String)
{
    //adds a line in between each iteration of the puzzle
    print(" ")
    var i = 1;
    var once =  true;
    while ( i < 82)
    {
        if (view.count > i)
        {
            var temp = CharacterPosition(i, view);
            
            if (temp == "0")
            {
                temp = " ";
            }
            print(temp, terminator:"");
        }
        else
        {
            print(" ", terminator:"");
            
        }
       if (once == true)
        {
            once = false;
        }
        else
        {
            if (i % 9 == 0)
            {
                print("");
            }
        }
        
        if (i % 9  == 3 || i % 9  == 6)
        {
            print("|" , terminator:"");
        }
        if (i == 27 || i == 54)
        {
            print("-----------");
        }
        i+=1;
    }
}


//used to solve the puzzle that
func Solve(input: Array<Array<Int>>) -> (String)
{
    var input = input
    var diff = 0
    
    //while the puzzle is not solved
    while (isSolved(input: &input) != true)
    {
        let input1 = input
        //move to the search function
        let ans = Search(input: input)
        //set input equal to the return value of input
        //which is an Array<Array<Int>>
        input = ans.0
        //if the shortestPossibility == 0
        //position = Array<Int>
        if (ans.2.count == 0)
        {
            break;
        }
        //draw the grid with the current array
        DrawGrid(view: ArrayToString(input: input))
        
        //checks to see if the new input equals the old input
        if (input == input1)
        {
            //add to the difference
            diff += 1
        }
        //if the new input != old input reset the difference
        else
        {
            diff = 0
        }
        //if difference is greater or equal to 2
        if (diff >= 2)
        {
            //set tempDepth to the value returned from Depth
            let tempDepth = Depth(input: input, ans: ans)
            //if the depth search returns true
            if (tempDepth.1 == true)
            {
                //input = Array<Array<Int>> from Depth()
                input = tempDepth.0;
                break
            }
            //difference reset to 0
            diff = 0
        }
        
    }
    //return the array as a string
    return(ArrayToString(input:input))
}


func Menu() -> String
{
    print("1) Enter Numbers")
    print("2) Auto Generate Numbers")
    let input1 = readLine()!
    
    if (input1 == "1")
    {
        var i = 0;
        var originalString = " ";
        var godstring2 = " ";
        
        while (i < 9)
        {
            print("Type the \(i + 1) th line (1-9 and 0 being blank)");
            var input2 = readLine()!
            
            while (input2.count < 9)
            {
                input2.append("0");
            }
            godstring2.append(input2);
            DrawGrid(view: godstring2);
            print("\n1) redoline");
            if (i == 8)
            {
                print("2) Solve");
            }
            else
            {
                print("2) nextline");
            }
            let input3 = readLine()!
            if (input3 == "1")
            {
                godstring2 = originalString;
            }
            if (input3 == "2")
            {
                originalString = godstring2;
                i += 1;
            }
            
        }
        return(originalString)
        
    }
    if (input1 == "2")
    {
        var originalString = ""
        print("1=ez 2=med 3=hard 4=ex 5= auto")
        let input4 = readLine()!
        if (input4 == "1")
        {
            originalString = " 501627000820090013640000000960401300080730429004900500006075030200369005050000190"
        }
        if (input4 == "2")
        {
            originalString = " 200000000000000000000000000000000000000000000000000000000000000000000000000000000"
        }
        if (input4 == "3")
        {
            originalString = " 000000008300000500004300091001046750049000010070005000000400060000081004005000073"
        }
        if (input4 == "4")
        {
            originalString = " 000030002000900830100700540080004000000050080470000306000060415009501060600000000"
        }
        if (input4 == "5")
        {
            originalString = GenerateString();
            print(originalString)
            let _ = readLine();
        }
        
        
        return(originalString)
    }
    
    return(input1)
}


//converts a string to an array
//takes in a string and outputs an Array<Array<Int>>
func StringToArray(input: String) -> Array<Array<Int>>
{
    
    var ans = Array(repeating: Array(repeating: 0, count: 9), count: 9)
    var x = 0;
    var y = 0;
    var count = 1;
    
    //while not all collumns have been iterated through
    while (y < 9)
    {
        //while not all rows have been iterated through
        while (x < 9)
        {
            //get the position of the character and assign it to temp1
            let temp1 = String(CharacterPosition(count, input));
            let temp2 = Int(temp1)!
            ans[x][y] = (temp2);
            
            //move to the next item in the string
            count += 1;
            //move along the row
            x += 1;
        }
        //reset the rows
        x = 0;
        //move to the next collumn
        y += 1;
    }
    //return the value of ans
    //ans = Array<Array<Int>>
    return(ans)
}

//convert the array to a string
//take in an Array<Array<Int>> and return a string
func ArrayToString(input: Array<Array<Int>>) -> String
{
    var ans = " "
    var x = 0 ;
    var y = 0;
    //while not all of the collumns have been iterated through
    while (y < 9)
    {
        //while not all of the rows have been iterated through
        while (x < 9)
        {
            //temp = the value of the inputted array
            var temp1 = input[x][y]
            temp1 += 48;
            let temp2 = Character(UnicodeScalar(temp1)!);
            ans.append(temp2);
            x += 1;
        }
        //reset the row value
        x = 0;
        //move to the next collumn
        y += 1;
    }
    //return the ans as a string
    return(ans);
}

func GenerateString() -> String
{
    var tempVal = " "
    for _ in 0..<81
    {
        tempVal.append("0")
    }
    
    var i = 1
    while (i < 10)
    {
        var seed = Int((Date().timeIntervalSinceReferenceDate * 10000000000 )) % 1000
        seed *= 7 * i
        seed =  seed % 81
        print(seed)
        var temp = Array(tempVal)
        temp[seed] = Character(UnicodeScalar(i + 48)!);
        tempVal = String(temp)
        i += 1
    }
    
    tempVal = Solve(input: StringToArray(input: tempVal))
    
    
    
    //Permutation
    
    var tempVal2 = Array(tempVal)
    
    var seed = Int((Date().timeIntervalSinceReferenceDate * 10000000000 )) % 100
    seed = Int((Date().timeIntervalSinceReferenceDate * 10000000000 )) % 100
    
    print(seed)
    seed *= 7
    print(seed)
    seed =  seed % 20
    print(seed)
    
    seed += 40
    for i in 0..<seed
    {
        var seed1 = Int((Date().timeIntervalSinceReferenceDate * 10000000000 )) % 100
        print(seed1, "big boy")
        seed1 *= 7 * i
        print(seed1, "xi")
        
        seed1 =  seed1 % 81
        print(seed1, " %81")
        
        tempVal2[seed1] = "0"
        print(seed1, "finals")
        
    }
    
    tempVal = String(tempVal2)
    
    DrawGrid(view: tempVal)
    readLine()
    
    return(tempVal)
}


//function to remove zeroes to make it easier to see
//what is happening with the puzzle
//have a blank space instead of a zero to see what spaces are
//empty
func RemoveZeroes(opt: Array<Int>) -> Array<Int>
{
    var tempOpt = opt
    var i = opt.count - 1
    while (i > -1)
    {
        //if opt is == 0 then remove the zero
        if (opt[i] == 0)
        {
            
            tempOpt.remove(at: i)
        }
        //reduce i by 1
        i -= 1
    }
    //return the array
    return(tempOpt)
}


//function for depth search
//takes in an input - Array<Array<Int>> and ans which contains an Array<Array<Int>>(input/mainstring),
//Array<Int>(position) and an Array<Int>(shortestPossibility)
//outputs and Array<Array<Int>> and a bool for success
func Depth(input: Array<Array<Int>>, ans : (Array<Array<Int>>, Array<Int>, Array<Int>)) -> (input: Array<Array<Int>>, success: Bool)
{
    let input = input
    var i = 0
    var inputTemp = input
    var diff1 = 0
    
    //while i is less than the shortest possibility
    while (i < ans.2.count)
    {
        
        inputTemp[ans.1[0]][ans.1[1]] = ans.2[i]
        //make inputTemp1 = inputTemp
        let inputTemp1 = inputTemp
        //set ans to the return of search
        let ans = Search(input: inputTemp)
        //set imputTemp to mainArray
        inputTemp = ans.0
        //draw the puzzle grid
        DrawGrid(view: ArrayToString(input: inputTemp))
        
        //checks to see if the puzzle has been solved
        if (isSolved(input: &inputTemp) == true)
        {
            //returns inputTemp and success as true
            return(inputTemp, true)
        }
        //if inputTemp = inputTemp1
        if (inputTemp == inputTemp1)
        {
            //add to the difference
            diff1 += 1
        }
        //otherwise reset difference
        else
        {
            diff1 = 0
        }
        //if difference is equal or greater than 2
        if (diff1 >= 2)
        {
            //call depth again
            let tempDepth = Depth(input: inputTemp, ans: ans)
            //if tempDepth ans = true
            if (tempDepth.1 == true)
            {
                //return the originalArray and success as true
                return(tempDepth.0, true)
            }
            //increment i by 1
            i += 1
            //reset difference
            diff1 = 0
            //inputTemp = input
            inputTemp = input
            
        }
    }
    //if it can't find the answer return the 2D Array and success as false
    return(input, false)
    
}

//function that runs through the search
func Search(input: Array<Array<Int>>) -> (input: Array<Array<Int>>, position: Array<Int>, shortestpossibility: Array<Int>)
{
    var input = input
    let possibility = [1,2,3,4,5,6,7,8,9]
    var possibilitytemp = possibility;
    var possibilitytemp2 = possibility;
    var shortestpossibility = possibility;
    var shortestpos = [0, 0]
    var x = 0;
    var y = 0;
    mainLoop: while (y < 9)
    {
        while (x < 9)
        {
            if (input[x][y] == 0)
            {
                var possibilitytemp = possibility;
                possibilitytemp = QBoxCheck(input: input, X: x, Y: y, possibility: possibilitytemp)
                possibilitytemp2 = RemoveZeroes(opt: possibilitytemp)
                if (possibilitytemp2.count > 1)
                {
                    possibilitytemp = QVCheck(input: input, X: x, Y: y, possibility: possibilitytemp)
                    possibilitytemp2 = RemoveZeroes(opt: possibilitytemp)
                    if (possibilitytemp2.count > 1)
                    {
                        possibilitytemp = QHCheck(input: input, X: x, Y: y, possibility: possibilitytemp)
                        possibilitytemp2 = RemoveZeroes(opt: possibilitytemp)
                        print(possibilitytemp2)
                        if (possibilitytemp2.count > 1)
                        {
                            if (shortestpossibility.count > possibilitytemp2.count)
                            {
                                shortestpossibility = possibilitytemp2
                                shortestpos = [x, y]
                            }
                            
                        }
                        else if (possibilitytemp2.count == 0)
                        {
                            print("problem is unsolvable, 0 possible soultions at position: ", x, ", ",y)
                            shortestpossibility = possibilitytemp2
                            shortestpos = [x, y]
                            break mainLoop;
                        }
                        else
                        {
                            shortestpossibility = possibilitytemp2
                            shortestpos = [x, y]
                            input[x][y] = possibilitytemp2[0]
                            break mainLoop;
                        }
                    }
                    else if (possibilitytemp2.count == 0)
                    {
                        print("problem is unsolvable, 0 possible soultions at position: ", x, ", ",y)
                        shortestpossibility = possibilitytemp2
                        shortestpos = [x, y]
                        break mainLoop;
                    }
                    else
                    {
                        shortestpossibility = possibilitytemp2
                        shortestpos = [x, y]
                        input[x][y] = possibilitytemp2[0]
                        break mainLoop;
                    }
                }
                else if (possibilitytemp2.count == 0)
                {
                    print("problem is unsolvable, 0 possible soultions at position: ", x, ", ",y)
                    shortestpossibility = possibilitytemp2
                    shortestpos = [x, y]
                    break mainLoop;
                }
                else
                {
                    shortestpossibility = possibilitytemp2
                    shortestpos = [x, y]
                    input[x][y] = possibilitytemp2[0]
                    break mainLoop;
                }
            }
            x += 1;
        }
        x = 0
        y += 1;
    }
    return(input, shortestpos, shortestpossibility)
}


//Checks to see if the sudoku puzzle has been solved
//returns either true or false based on whether or not
//the puzzle has been solved
func isSolved(input: inout Array<Array<Int>>) -> Bool
{
    //bool to see if the puzzle has been finished
    var isFinished = true;
    var x = 0;
    var y = 0;
    //checks collumms
    while (y < 9)
    {
        //checks rows
        while (x < 9)
        {
            //checks to see if there are any empty spaces
            if (input[x][y] == 0)
            {
                isFinished = false;
            }
            //check next value in the row
            x += 1;
        }
        //reset row value back to the first one
        x = 0
        //move to the next collumn
        y += 1;
    }
    //return whether the puzzle is finished or not
    return(isFinished);
}

//checks boxes for the puzzle grid
func QBoxCheck(input: Array<Array<Int>>, X: Int, Y: Int, possibility: Array<Int>) -> Array<Int>
{
    var box = [0,0];
    var possibility = possibility;
    //left most boxes
    if (0...2).contains(X)
    {
        //checks to see if it is the top left box
        if (0...2).contains(Y)
        {
            box = [0,0];
        }
        //checks to see if it is the middle left box
        if (3...5).contains(Y)
        {
            box = [0,3]
        }
        //checks to see if it is the bottom left box
        if (6...8).contains(Y)
        {
            box = [0,6]
        }
    }
    //middle row boxes
    if (3...5).contains(X)
    {
        //checks to see if it is the top center box
        if (0...2).contains(Y)
        {
            box = [3,0]
        }
        //checks to see if it is the middle box
        if (3...5).contains(Y)
        {
            box = [3,3]
        }
        //checks to see if it is the center bottom box
        if (6...8).contains(Y)
        {
            box = [3,6]
        }
    }
    //right most boxes
    if (6...8).contains(X)
    {
        //checks to see if it is the top right box
        if (0...2).contains(Y)
        {
            box = [6,0]
        }
        //checks to see if it is the right middle box
        if (3...5).contains(Y)
        {
            box = [6,3]
        }
        //checks to see if it is the bottom right box
        if (6...8).contains(Y)
        {
            box = [6,6]
        }
    }
    
    
    var x = 0
    var y = 0
    var temp = 0
    //while there are still collumns
    while(y < 3)
    {
        //while there is still value in the row
        while(x < 3)
        {
            temp = input[x + box[0]][y + box[1]]
            if (temp != 0)
            {
                possibility[temp - 1] = 0
            }
            //move to the next value in the row
            x += 1;
        }
        //reset row value
        x = 0
        //move to the next collumn
        y += 1;
    }
    //return possibility Array<Int>
    return(possibility)
}

//checks y value
func QVCheck(input: Array<Array<Int>>, X: Int, Y: Int, possibility: Array<Int>) -> Array<Int>
{
    
    var possibility = possibility;
    var i = 0;
    var temp = 0;
    //while i is less than 9
    while (i < 9)
    {
        temp = input[X][i]
        //if temp is not 0
        if (temp != 0)
        {
            possibility[temp - 1] = 0
        }
        //increment i
        i += 1
    }
    //return possibility Array<Int>
    return(possibility)
}

//checks x value
func QHCheck(input: Array<Array<Int>>, X: Int, Y: Int, possibility: Array<Int>) -> Array<Int>
{
    var possibility = possibility;
    var i = 0;
    var temp = 0;
    //while i is less than 9
    while (i < 9)
    {
        temp = input[i][Y]
        //if temp is not 0
        if (temp != 0)
        {
            possibility[temp - 1] = 0
        }
        //increment i
        i += 1
    }
    //return possibility Array<Int>
    return(possibility)
}



//gameplay loop
//makes it so the program will always run
while (true)
{
    
    let originalString = Menu();
    let originalArray = StringToArray(input: originalString)
    Solve(input: originalArray)
    let _ = readLine();
}



